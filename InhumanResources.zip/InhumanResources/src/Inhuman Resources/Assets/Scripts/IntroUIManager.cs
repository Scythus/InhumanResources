﻿using UnityEngine;
using System.Collections;

public class IntroUIManager : MonoBehaviour {

    public void startGame()
    {
        Application.LoadLevel("CV");
    }
}
