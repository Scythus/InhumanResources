﻿using UnityEngine;
using System.Collections;

public class TotalScore : MonoBehaviour {
    public static float totalScore;
}
